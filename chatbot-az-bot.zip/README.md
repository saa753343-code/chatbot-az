# ChatBot.az — Telegram Bot

## Quraşdırma / Установка

### 1. Yerli işlətmə / Локальный запуск

```bash
pip install -r requirements.txt
export TELEGRAM_TOKEN="sizin_tokeniniz"
export GROQ_API_KEY="sizin_groq_keyiniz"
python bot.py
```

### 2. Railway.app-da pulsuz yerləşdirmə / Бесплатный деплой на Railway

1. railway.app saytına gedin → GitHub ilə qeydiyyat
2. "New Project" → "Deploy from GitHub repo"
3. Bu faylları GitHub-a yükləyin
4. Variables bölməsində əlavə edin:
   - TELEGRAM_TOKEN = tokeniniz
   - GROQ_API_KEY = groq keyiniz
5. Deploy edin — bot işə düşür!

### 3. Yeni müştəri üçün necə uyğunlaşdırmaq / Как настроить для нового клиента

bot.py faylında BUSINESS_INFO dəyişənini redaktə edin:
- Biznes adı, ünvan, telefon
- Xidmətlər / menyu / qiymətlər
- İş saatları
- Xüsusi şərtlər

Hər müştəri üçün ayrı bot yaradın (@BotFather-dən)
və ayrı TELEGRAM_TOKEN istifadə edin.

## Müştəri başına xərc / Расходы на клиента
- Groq API: PULSUZ (dəqiqədə 30 sorğu)
- Railway hosting: PULSUZ (ilk 500 saat/ay)
- Sizin qazancınız: 79-149 AZN/ay müştəridən
